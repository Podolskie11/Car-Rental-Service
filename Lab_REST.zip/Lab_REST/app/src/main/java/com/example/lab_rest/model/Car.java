package com.example.lab_rest.model;

import java.sql.Timestamp;

public class Car {
    private int CarID;
    private String Model;
    private String Brand;
    private String PlateNumber;
    private String availability;

    private String image;
    private String CreatedAt;

    public Car() {
    }

    public Car(int CarID, String Model, String Brand, String PlateNumber, String availability, String CreatedAt, String image) {
        this.CarID = CarID;
        this.Model = Model;
        this.Brand = Brand;
        this.PlateNumber = PlateNumber;
        this.availability = availability;
        this.CreatedAt = CreatedAt;
        this.image = image;
    }

    public int getCarID() {
        return CarID;
    }

    public void setCarID(int CarID) {
        this.CarID = CarID;
    }

    public String getModel() {
        return Model;
    }

    public void setModel(String Model) {
        this.Model = Model;
    }

    public String getBrand() {
        return Brand;
    }

    public void setBrand(String Brand) {
        this.Brand = Brand;
    }

    public String getPlateNumber() {
        return PlateNumber;
    }

    public void setPlateNumber(String PlateNumber) {
        this.PlateNumber = PlateNumber;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public String getCreatedAt() {
        return CreatedAt;
    }

    public void setCreatedAt(String createdAt) {
        this.CreatedAt = createdAt;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
    @Override
    public String toString() {
        return Model ;
    }

}
