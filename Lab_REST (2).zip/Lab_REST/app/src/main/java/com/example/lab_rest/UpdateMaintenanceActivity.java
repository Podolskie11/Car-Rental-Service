package com.example.lab_rest;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.DialogFragment;

import com.example.lab_rest.model.Maintenance;
import com.example.lab_rest.model.User;
import com.example.lab_rest.remote.ApiUtils;
import com.example.lab_rest.remote.MaintenanceService;
import com.example.lab_rest.sharedpref.SharedPrefManager;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateMaintenanceActivity extends AppCompatActivity {

    private EditText txtType;
    private EditText txtCost;
    private static TextView tvMaintenanceDate;
    private Maintenance maintenance;
    private Maintenance updatedMaintenance;

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            Date selectedDate = new GregorianCalendar(year, month, day).getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
            tvMaintenanceDate.setText(sdf.format(selectedDate));
        }
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new UpdateMaintenanceActivity.DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_maintenance);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        int maintenance_id = intent.getIntExtra("maintenance_id", -1);

        txtType = findViewById(R.id.txtType);
        txtCost = findViewById(R.id.txtCost);
        tvMaintenanceDate = findViewById(R.id.tvMaintenanceDate);

        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        MaintenanceService maintenanceService = ApiUtils.getMaintenanceService();

        maintenanceService.getMaintenance(user.getToken(), maintenance_id).enqueue(new Callback<Maintenance>() {
            @Override
            public void onResponse(Call<Maintenance> call, Response<Maintenance> response) {
                Log.d("MyApp:", "Update Form Populate Response: " + response.raw().toString());
                if (response.code() == 200) {
                    maintenance = response.body();
                    txtType.setText(maintenance.getType());
                    txtCost.setText(String.format("%.2f", maintenance.getCost()));
                    tvMaintenanceDate.setText(maintenance.getMaintenanceDate());
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    try {
                        Date maintenanceDate = sdf.parse(maintenance.getMaintenanceDate());
                        tvMaintenanceDate.setText(sdf.format(maintenanceDate));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                } else if (response.code() == 401) {
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp: ", response.toString());
                }
            }

            @Override
            public void onFailure(Call<Maintenance> call, Throwable t) {
                Toast.makeText(UpdateMaintenanceActivity.this, "Error connecting", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void updateMaintenance(View view) {
        String type = txtType.getText().toString();
        String costS = txtCost.getText().toString();
        double cost = Double.parseDouble(costS);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String maintenanceDate = tvMaintenanceDate.getText().toString();
        String updated_at = sdf.format(new Date());

        Log.d("MyApp:", "Old Maintenance info: " + maintenance.toString());

        maintenance.setType(type);
        maintenance.setCost(cost);
        maintenance.setMaintenanceDate(maintenanceDate);
        maintenance.setUpdateMaintenanceDate(updated_at);

        Log.d("MyApp:", "New Maintenance info: " + maintenance.toString());

        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        MaintenanceService maintenanceService = ApiUtils.getMaintenanceService();
        Call<Maintenance> call = maintenanceService.updateMaintenance(user.getToken(), maintenance.getMaintenanceID(),
                maintenance.getType(), maintenance.getCost(), maintenance.getMaintenanceDate(), maintenance.getUpdateMaintenanceDate());

        call.enqueue(new Callback<Maintenance>() {
            @Override
            public void onResponse(Call<Maintenance> call, Response<Maintenance> response) {
                Log.d("MyApp:", "Update Request Response: " + response.raw().toString());
                if (response.code() == 200) {
                    updatedMaintenance = response.body();
                    showAlertDialog();
                } else if (response.code() == 401) {
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp: ", response.toString());
                }
            }

            @Override
            public void onFailure(Call<Maintenance> call, Throwable t) {
                displayAlert("Error [" + t.getMessage() + "]");
                Log.d("MyApp:", "Error: " + t.getCause().getMessage());
            }
        });
    }

    public void clearSessionAndRedirect() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();
        finish();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void showAlertDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(updatedMaintenance.getType() + " updated successfully");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Intent intent = new Intent(getApplicationContext(), MaintenanceListActivity.class);
                startActivity(intent);
                finish();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }
}
