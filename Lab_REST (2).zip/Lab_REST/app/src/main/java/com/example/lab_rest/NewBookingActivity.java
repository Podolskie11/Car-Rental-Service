package com.example.lab_rest;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.DialogFragment;

import com.example.lab_rest.model.Booking;
import com.example.lab_rest.model.Car;
import com.example.lab_rest.model.User;
import com.example.lab_rest.remote.ApiUtils;
import com.example.lab_rest.remote.BookingService;
import com.example.lab_rest.remote.CarService;
import com.example.lab_rest.sharedpref.SharedPrefManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewBookingActivity extends AppCompatActivity {

    private Spinner spCar;
    private static TextView tvBookingDate;
    private static Date bookingDate;
    private EditText txtRemarks;
    private EditText txtStatus;
    private static TextView tvCreatedAt;
    private static Date createdAt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_new_booking);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spCar = findViewById(R.id.spCar);
        tvBookingDate = findViewById(R.id.tvBookingDate);
        txtRemarks = findViewById(R.id.txtRemarks);
        txtStatus = findViewById(R.id.txtStatus);
        tvCreatedAt = findViewById(R.id.tvCreatedAt);

        fetchAllCarModel();

        bookingDate = new Date();
        createdAt = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
        tvBookingDate.setText(sdf.format(bookingDate));
        tvCreatedAt.setText(sdf.format(createdAt));
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void showDatePickerDialogForCreatedAt(View v) {
        DialogFragment newFragment = new DatePickerFragmentForCreatedAt();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void addNewBooking(View v) {
        int carId = ((Car) spCar.getSelectedItem()).getCarID();
        String remarks = txtRemarks.getText().toString();
        String status = txtStatus.getText().toString();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        String booking_date = sdf.format(bookingDate);
        String created_at = sdf.format(createdAt);

        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();

        BookingService bookingService = ApiUtils.getBookingService();
        Call<Booking> call = bookingService.addBooking(user.getToken(), user.getId(), carId, booking_date, status, remarks, created_at);

        call.enqueue(new Callback<Booking>() {
            @Override
            public void onResponse(Call<Booking> call, Response<Booking> response) {
                Log.d("MyApp:", "Response: " + response.raw().toString());
                if (response.code() == 201) {
                    Booking addedBooking = response.body();
                    Toast.makeText(getApplicationContext(), "Booking added successfully.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), BookingListActivity.class);
                    startActivity(intent);
                    finish();
                } else if (response.code() == 401) {
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp: ", response.toString());
                }
            }

            @Override
            public void onFailure(Call<Booking> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Error [" + t.getMessage() + "]", Toast.LENGTH_LONG).show();
                Log.d("MyApp:", "Error: " + t.getCause().getMessage());
            }
        });
    }

    private void fetchAllCarModel() {
        CarService carService = ApiUtils.getCarService();
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        Call<List<Car>> call = carService.getAllCars(user.getToken());
        call.enqueue(new Callback<List<Car>>() {
            @Override
            public void onResponse(Call<List<Car>> call, Response<List<Car>> response) {
                if (response.code() == 200) {
                    List<Car> carList = response.body();
                    ArrayAdapter<Car> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, carList);
                    spCar.setAdapter(adapter);
                } else if (response.code() == 401) {
                    Toast.makeText(NewBookingActivity.this, "Unauthorized access. Please login again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Car>> call, Throwable t) {
                Toast.makeText(NewBookingActivity.this, "Error fetching car models: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void clearSessionAndRedirect() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();
        finish();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            bookingDate = new GregorianCalendar(year, month, day).getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
            tvBookingDate.setText(sdf.format(bookingDate));
        }
    }

    public static class DatePickerFragmentForCreatedAt extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            createdAt = new GregorianCalendar(year, month, day).getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
            tvCreatedAt.setText(sdf.format(createdAt));
        }
    }
}
