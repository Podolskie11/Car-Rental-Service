package com.example.lab_rest;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.DialogFragment;

import com.example.lab_rest.model.Car;
import com.example.lab_rest.model.Maintenance;
import com.example.lab_rest.model.User;
import com.example.lab_rest.remote.ApiUtils;
import com.example.lab_rest.remote.CarService;
import com.example.lab_rest.remote.MaintenanceService;
import com.example.lab_rest.sharedpref.SharedPrefManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NewMaintenanceActivity extends AppCompatActivity {

    private Spinner spCar;
    private EditText txtType;
    private EditText txtCost;
    private static TextView tvMaintenanceDate;
    private static Date maintenanceDate;
    private static Date updateMaintenanceDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_new_maintenance);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spCar = findViewById(R.id.spCar);
        txtType = findViewById(R.id.txtType);
        txtCost = findViewById(R.id.txtCost);
        tvMaintenanceDate = findViewById(R.id.tvMaintenanceDate);

        fetchAllCarModel();

        maintenanceDate = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
        tvMaintenanceDate.setText(sdf.format(maintenanceDate));
    }

    public void showDatePickerDialog(View v) {
        DialogFragment newFragment = new DatePickerFragment();
        newFragment.show(getSupportFragmentManager(), "datePicker");
    }

    public void addNewMaintenance(View v) {
        int carId = ((Car) spCar.getSelectedItem()).getCarID();
        String type = txtType.getText().toString();
        String costS = txtCost.getText().toString();
        double cost = Double.parseDouble(costS);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
        String maintenance_date = sdf.format(maintenanceDate);

        // Setting updateMaintenanceDate to current time
        updateMaintenanceDate = new Date();
        String update_maintenance_date = sdf.format(updateMaintenanceDate);

        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();

        MaintenanceService maintenanceService = ApiUtils.getMaintenanceService();
        Call<Maintenance> call = maintenanceService.addMaintenance(user.getToken(), carId, type, cost, maintenance_date, update_maintenance_date);

        call.enqueue(new Callback<Maintenance>() {
            @Override
            public void onResponse(Call<Maintenance> call, Response<Maintenance> response) {
                Log.d("MyApp:", "Response: " + response.raw().toString());

                if (response.code() == 201) {
                    Maintenance addedMaintenance = response.body();
                    Toast.makeText(getApplicationContext(), addedMaintenance.getType() + " added successfully.", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(getApplicationContext(), MaintenanceListActivity.class);
                    startActivity(intent);
                    finish();
                } else if (response.code() == 401) {
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp: ", response.toString());
                }
            }

            @Override
            public void onFailure(Call<Maintenance> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Error [" + t.getMessage() + "]", Toast.LENGTH_LONG).show();
                Log.d("MyApp:", "Error: " + t.getCause().getMessage());
            }
        });
    }

    private void fetchAllCarModel() {
        CarService carService = ApiUtils.getCarService();
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        Call<List<Car>> call = carService.getAllCars(user.getToken());
        call.enqueue(new Callback<List<Car>>() {
            @Override
            public void onResponse(Call<List<Car>> call, Response<List<Car>> response) {
                if (response.code() == 200) {
                    List<Car> carList = response.body();
                    ArrayAdapter<Car> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, carList);
                    spCar.setAdapter(adapter);
                } else if (response.code() == 401) {
                    Toast.makeText(NewMaintenanceActivity.this, "Unauthorized access. Please login again.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<Car>> call, Throwable t) {
                Toast.makeText(NewMaintenanceActivity.this, "Error fetching car models: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void clearSessionAndRedirect() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();
        finish();
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public static class DatePickerFragment extends DialogFragment implements DatePickerDialog.OnDateSetListener {
        @Override
        public Dialog onCreateDialog(Bundle savedInstanceState) {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            return new DatePickerDialog(getActivity(), this, year, month, day);
        }

        public void onDateSet(DatePicker view, int year, int month, int day) {
            maintenanceDate = new GregorianCalendar(year, month, day).getTime();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.UK);
            tvMaintenanceDate.setText(sdf.format(maintenanceDate));
        }
    }
}
