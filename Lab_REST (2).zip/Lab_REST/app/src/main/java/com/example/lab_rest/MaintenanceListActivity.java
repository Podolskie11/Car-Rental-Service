package com.example.lab_rest;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab_rest.adapter.MaintenanceAdapter;
import com.example.lab_rest.model.Maintenance;
import com.example.lab_rest.model.DeleteResponse;
import com.example.lab_rest.model.User;
import com.example.lab_rest.remote.ApiUtils;
import com.example.lab_rest.remote.MaintenanceService;
import com.example.lab_rest.sharedpref.SharedPrefManager;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MaintenanceListActivity extends AppCompatActivity {

    private MaintenanceService maintenanceService;
    private RecyclerView rvMaintenanceList;
    private MaintenanceAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_maintenance_list);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rvMaintenanceList = findViewById(R.id.rvMaintenanceList);

        registerForContextMenu(rvMaintenanceList);

        updateListView();
    }

    private void updateListView() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();
        String token = user.getToken();

        maintenanceService = ApiUtils.getMaintenanceService();

        maintenanceService.getAllMaintenances(token).enqueue(new Callback<List<Maintenance>>() {
            @Override
            public void onResponse(Call<List<Maintenance>> call, Response<List<Maintenance>> response) {
                Log.d("MyApp:", "Response: " + response.raw().toString());

                if (response.code() == 200) {
                    List<Maintenance> maintenances = response.body();

                    adapter = new MaintenanceAdapter(getApplicationContext(), maintenances);
                    rvMaintenanceList.setAdapter(adapter);
                    rvMaintenanceList.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

                    DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(rvMaintenanceList.getContext(),
                            DividerItemDecoration.VERTICAL);
                    rvMaintenanceList.addItemDecoration(dividerItemDecoration);
                } else if (response.code() == 401) {
                    Toast.makeText(getApplicationContext(), "Invalid session. Please login again", Toast.LENGTH_LONG).show();
                    clearSessionAndRedirect();
                } else {
                    Toast.makeText(getApplicationContext(), "Error: " + response.message(), Toast.LENGTH_LONG).show();
                    Log.e("MyApp: ", response.toString());
                }
            }

            @Override
            public void onFailure(Call<List<Maintenance>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "Error connecting to the server", Toast.LENGTH_LONG).show();
                Log.e("MyApp:", t.toString());
            }
        });
    }

    public void clearSessionAndRedirect() {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        spm.logout();

        finish();

        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.maintenance_context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Maintenance selectedMaintenance = adapter.getSelectedItem();
        Log.d("MyApp", "selected " + selectedMaintenance.toString());

        if (item.getItemId() == R.id.menDetails) {
            doViewDetails(selectedMaintenance);
        } else if (item.getItemId() == R.id.menDelete) {
            doDeleteMaintenance(selectedMaintenance);
        } else if (item.getItemId() == R.id.menUpdate) {
            doUpdateMaintenance(selectedMaintenance);
        }

        return super.onContextItemSelected(item);
    }

    private void doUpdateMaintenance(Maintenance selectedMaintenance) {
        Log.d("MyApp:", "updating maintenance: " + selectedMaintenance.toString());
        Intent intent = new Intent(getApplicationContext(), UpdateMaintenanceActivity.class);
        intent.putExtra("maintenance_id", selectedMaintenance.getMaintenanceID());
        startActivity(intent);
    }

    private void doViewDetails(Maintenance selectedMaintenance) {
        Log.d("MyApp:", "viewing details: " + selectedMaintenance.toString());
        Intent intent = new Intent(getApplicationContext(), MaintenanceDetailsActivity.class);
        intent.putExtra("maintenance_id", selectedMaintenance.getMaintenanceID());
        startActivity(intent);
    }

    private void doDeleteMaintenance(Maintenance selectedMaintenance) {
        SharedPrefManager spm = new SharedPrefManager(getApplicationContext());
        User user = spm.getUser();

        MaintenanceService maintenanceService = ApiUtils.getMaintenanceService();
        Call<DeleteResponse> call = maintenanceService.deleteMaintenance(user.getToken(), selectedMaintenance.getMaintenanceID());

        call.enqueue(new Callback<DeleteResponse>() {
            @Override
            public void onResponse(Call<DeleteResponse> call, Response<DeleteResponse> response) {
                if (response.code() == 200) {
                    displayAlert("Maintenance successfully deleted");
                    updateListView();
                } else {
                    displayAlert("Maintenance failed to delete");
                    Log.e("MyApp:", response.raw().toString());
                }
            }

            @Override
            public void onFailure(Call<DeleteResponse> call, Throwable t) {
                displayAlert("Error [" + t.getMessage() + "]");
                Log.e("MyApp:", t.getMessage());
            }
        });
    }

    public void displayAlert(String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(message)
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public void floatingAddMaintenanceClicked(View view) {
        Intent intent = new Intent(getApplicationContext(), NewMaintenanceActivity.class);
        startActivity(intent);
    }
}
