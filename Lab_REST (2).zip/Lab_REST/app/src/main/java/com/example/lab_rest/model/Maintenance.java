package com.example.lab_rest.model;

import java.sql.Date;

public class Maintenance {

    private int maintenanceID;
    private int cardId;
    private Date maintenanceDate;
    private Date updateMaintenanceDate;
    private String type;
    private double cost;
    private Car car;  // Adding the Car object

    public Maintenance() {
    }

    public Maintenance(int maintenanceID, int cardId, Date maintenanceDate, Date updateMaintenanceDate, String type, double cost, Car car) {
        this.maintenanceID = maintenanceID;
        this.cardId = cardId;
        this.maintenanceDate = maintenanceDate;
        this.updateMaintenanceDate = updateMaintenanceDate;
        this.type = type;
        this.cost = cost;
        this.car = car;
    }

    public int getMaintenanceID() {
        return maintenanceID;
    }

    public void setMaintenanceID(int maintenanceID) {
        this.maintenanceID = maintenanceID;
    }

    public int getCardId() {
        return cardId;
    }

    public void setCardId(int cardId) {
        this.cardId = cardId;
    }

    public Date getMaintenanceDate() {
        return maintenanceDate;
    }

    public void setMaintenanceDate(Date maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }

    public Date getUpdateMaintenanceDate() {
        return updateMaintenanceDate;
    }

    public void setUpdateMaintenanceDate(Date updateMaintenanceDate) {
        this.updateMaintenanceDate = updateMaintenanceDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    @Override
    public String toString() {
        return "Maintenance{" +
                "maintenanceID=" + maintenanceID +
                ", cardId=" + cardId +
                ", maintenanceDate=" + maintenanceDate +
                ", updateMaintenanceDate=" + updateMaintenanceDate +
                ", type='" + type + '\'' +
                ", cost=" + cost +
                ", car=" + car +
                '}';
    }
}
